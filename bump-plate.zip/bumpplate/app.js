/* Bump Plate app logic */
const $ = s => document.querySelector(s);
const DAY = 864e5;
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const store = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};
function toast(msg){ const t = $("#toast"); t.textContent = msg; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => t.hidden = true, 2600); }

/* ---------- Week ---------- */
let week = 14, tri = 2;
const savedDue = store.get("due", null);
$("#dueDate").value = savedDue || new Date(Date.now() + 26*7*DAY).toISOString().slice(0,10);
$("#exampleTag").hidden = !!savedDue;
function calcWeek(){
  const d = new Date($("#dueDate").value + "T12:00:00");
  if(isNaN(d)) return;
  const daysLeft = Math.round((d - Date.now()) / DAY);
  const gest = 280 - daysLeft;
  week = Math.max(1, Math.min(42, Math.floor(gest / 7)));
  const extra = Math.max(0, gest % 7);
  tri = week < 14 ? 1 : week < 28 ? 2 : 3;
  $("#weekNum").innerHTML = week + (extra ? `<small>+${extra}d</small>` : "") + "<small>weeks</small>";
  $("#triLabel").textContent = TRI[tri].name;
  $("#daysLeft").textContent = daysLeft > 0 ? `${daysLeft} days to go` : "Due date reached";
  $("#bar").style.width = Math.max(0, Math.min(100, gest / 280 * 100)) + "%";
  const t = TRI[tri];
  $("#weekCard").innerHTML = `<span class="label">Week ${week} · ${t.name}</span><h2>What matters right now</h2>
    <div class="nutr">${t.focus.map(([a,b]) => `<div><span class="label">${a}</span><strong>${b}</strong></div>`).join("")}</div>
    <ul class="list">${t.tips.map(x => `<li>${x}</li>`).join("")}</ul>`;
}
$("#dueDate").addEventListener("change", e => { store.set("due", e.target.value); $("#exampleTag").hidden = true; calcWeek(); });

/* ---------- Tabs ---------- */
document.querySelectorAll(".tabbar button").forEach(b => b.addEventListener("click", () => {
  document.querySelectorAll(".tabbar button").forEach(x => x.setAttribute("aria-selected", x === b));
  ["scan","guide","week"].forEach(t => $("#panel-" + t).hidden = t !== b.dataset.tab);
  window.scrollTo({top:0});
}));

/* ---------- Guide ---------- */
const SLABEL = {ok:"Okay", limit:"Careful", avoid:"Avoid"};
let gFilter = "all";
function renderGuide(){
  const q = $("#gq").value.trim().toLowerCase();
  const out = [];
  for(const c of FOODS){
    const items = c.items.filter(i => (gFilter === "all" || i.s === gFilter) && (!q || (i.n + " " + i.k.join(" ") + " " + i.d).toLowerCase().includes(q)));
    if(items.length) out.push(`<div class="card" style="gap:0"><h3 style="padding-bottom:6px">${c.cat}</h3>${items.map(i => `<div class="item"><span class="pill p-${i.s}">${SLABEL[i.s]}</span><b>${i.n}</b><p>${i.d}</p></div>`).join("")}</div>`);
  }
  $("#guideList").innerHTML = out.join("") || `<div class="card"><p class="muted">Nothing matches. Try scanning it instead.</p></div>`;
}
$("#gq").addEventListener("input", renderGuide);
document.querySelectorAll("#filters .chip").forEach(b => b.addEventListener("click", () => {
  gFilter = b.dataset.f; document.querySelectorAll("#filters .chip").forEach(x => x.setAttribute("aria-pressed", x === b)); renderGuide();
}));

/* ---------- Verdict card ---------- */
const WORD = {yes:"Yes", careful:"Careful", no:"No"};
function verdictCard({verdict, title, sub, img, reasons, extra}){
  return `<div class="verdict v-${verdict}">
    <div class="head"><span class="mark">${WORD[verdict]}</span>${img ? `<img src="${esc(img)}" alt="">` : ""}
      <div style="min-width:0"><span class="label">Week ${week}</span><h3>${esc(title)}</h3>${sub ? `<p class="small muted">${esc(sub)}</p>` : ""}</div></div>
    <ul>${reasons.map(r => `<li>${esc(r)}</li>`).join("")}</ul>${extra || ""}</div>`;
}

/* ---------- Product lookup ---------- */
const FIELDS = "product_name,product_name_en,generic_name,brands,ingredients_text,ingredients_text_en,categories_tags,labels_tags,nutriments,serving_size,image_front_small_url,quantity";
const memo = new Map();
async function fetchProduct(code){
  if(memo.has(code)) return memo.get(code);
  const tries = [code];
  if(code.length === 12) tries.push("0" + code);
  if(code.length === 13 && code.startsWith("0")) tries.push(code.slice(1));
  for(const c of tries){
    const r = await fetch(`https://world.openfoodfacts.org/api/v2/product/${c}.json?fields=${FIELDS}`);
    if(!r.ok && r.status !== 404) throw new Error("http " + r.status);
    const j = await r.json().catch(() => null);
    if(j && j.status === 1 && j.product){ memo.set(code, j.product); return j.product; }
  }
  memo.set(code, null);
  return null;
}

async function lookup(code){
  code = String(code).replace(/\D/g, "");
  if(code.length < 8){ toast("That barcode looks too short. Check the digits."); return; }
  const box = $("#result");
  box.innerHTML = `<div class="card"><div class="thinking"><span class="dot"></span>Looking up ${esc(code)}…</div></div>`;
  box.scrollIntoView({behavior:"smooth", block:"start"});
  let p;
  try{ p = await fetchProduct(code); }
  catch(e){
    box.innerHTML = `<div class="card"><p>Couldn't reach the product database. Check her signal and try again.</p><button class="ghost" style="align-self:flex-start" onclick="lookup('${code}')">Try again</button></div>`;
    return;
  }
  if(!p){
    box.innerHTML = `<div class="card"><h3>Product not found</h3><p class="muted">Barcode ${esc(code)} isn't in Open Food Facts yet. Type what it is below (like "smoked salmon" or "kombucha") to check it, or read the label for: raw/unpasteurized milk, alcohol, caffeine, deli meat, or high-mercury fish.</p>
      <a class="small" href="https://world.openfoodfacts.org/cgi/product.pl?code=${esc(code)}" target="_blank" rel="noopener">Add this product to Open Food Facts</a></div>`;
    $("#food").focus();
    return;
  }
  const res = checkProduct(p);
  const name = p.product_name_en || p.product_name || p.generic_name || "Unnamed product";
  const sub = [p.brands, p.quantity].filter(Boolean).join(" · ");
  const ing = p.ingredients_text_en || p.ingredients_text;
  let extra = "";
  if(res.caffeineNote) extra += `<p class="small"><b>Caffeine:</b> ${esc(res.caffeineNote)} Her daily limit is 200 mg.</p>`;
  if(ing) extra += `<details><summary>Ingredients</summary><p>${esc(ing)}</p></details>`;
  extra += `<p class="small muted">Barcode ${esc(code)} · <a href="https://world.openfoodfacts.org/product/${esc(code)}" target="_blank" rel="noopener">View on Open Food Facts</a></p>`;
  box.innerHTML = verdictCard({verdict: res.verdict, title: name, sub, img: p.image_front_small_url, reasons: res.reasons, extra});
  addHistory({code, name, verdict: res.verdict, t: Date.now()});
}

/* ---------- Typed food ---------- */
const VMAP = {ok:"yes", limit:"careful", avoid:"no"};
function checkFood(q){
  q = q.trim(); if(!q) return;
  const hits = matchFood(q);
  if(!hits.length){
    $("#result").innerHTML = `<div class="card"><p>"${esc(q)}" isn't in the guide. Try a simpler word (like "cheese" or "sushi"), browse the Food guide tab, or ask her OB.</p></div>`;
    return;
  }
  const worst = hits.reduce((a,b) => RANK[b.s] > RANK[a.s] ? b : a);
  $("#result").innerHTML = verdictCard({verdict: VMAP[worst.s], title: q, reasons: hits.map(h => `${h.n}: ${h.d}`)});
}

/* ---------- History ---------- */
function addHistory(h){
  const list = store.get("hist", []).filter(x => x.code !== h.code);
  list.unshift(h); store.set("hist", list.slice(0, 20)); renderHistory();
}
function renderHistory(){
  const list = store.get("hist", []);
  $("#histCard").hidden = !list.length;
  $("#hist").innerHTML = list.map(h => `<button data-code="${esc(h.code)}"><span class="pill p-${h.verdict}">${WORD[h.verdict]}</span><span>${esc(h.name)}</span></button>`).join("");
  $("#hist").querySelectorAll("button").forEach(b => b.onclick = () => lookup(b.dataset.code));
}
$("#clearHist").onclick = () => { store.set("hist", []); renderHistory(); };

/* ---------- Camera scanner ---------- */
let stream = null, stopLoop = null, zxReader = null, handled = false;
const FORMATS = ["ean_13","ean_8","upc_a","upc_e"];

function loadScript(src){ return new Promise((ok, no) => { const s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = no; document.head.appendChild(s); }); }

async function openCam(){
  if(!navigator.mediaDevices?.getUserMedia){ toast("This browser can't use the camera. Type the barcode number instead."); $("#code").focus(); return; }
  handled = false;
  $("#cam").hidden = false; $("#camMsg").textContent = "Starting camera…";
  const video = $("#video");
  const constraints = {audio:false, video:{facingMode:{ideal:"environment"}, width:{ideal:1280}, height:{ideal:720}}};
  try{
    let native = false;
    if("BarcodeDetector" in window){
      try{ const sup = await BarcodeDetector.getSupportedFormats(); native = FORMATS.some(f => sup.includes(f)); }catch(e){}
    }
    if(native){
      stream = await navigator.mediaDevices.getUserMedia(constraints);
      video.srcObject = stream; await video.play();
      const det = new BarcodeDetector({formats: FORMATS});
      let live = true; stopLoop = () => live = false;
      const tick = async () => {
        if(!live) return;
        try{ const codes = await det.detect(video); if(codes.length) return onCode(codes[0].rawValue); }catch(e){}
        setTimeout(tick, 120);
      };
      tick();
    } else {
      if(!window.ZXing) await loadScript("zxing.min.js");
      const hints = new Map();
      hints.set(ZXing.DecodeHintType.POSSIBLE_FORMATS, [ZXing.BarcodeFormat.EAN_13, ZXing.BarcodeFormat.EAN_8, ZXing.BarcodeFormat.UPC_A, ZXing.BarcodeFormat.UPC_E]);
      hints.set(ZXing.DecodeHintType.TRY_HARDER, true);
      zxReader = new ZXing.BrowserMultiFormatReader(hints, 150);
      await zxReader.decodeFromConstraints(constraints, video, (result) => { if(result) onCode(result.getText()); });
      stream = video.srcObject;
    }
    $("#camMsg").textContent = "Line up the barcode inside the box";
    setupTorch();
  }catch(e){
    closeCam();
    const denied = e && (e.name === "NotAllowedError" || e.name === "SecurityError");
    toast(denied ? "Camera permission is off. Allow it in the browser settings, or type the barcode." : "Couldn't start the camera. Type the barcode instead.");
  }
}
function setupTorch(){
  const track = stream?.getVideoTracks?.()[0];
  const caps = track?.getCapabilities?.();
  const btn = $("#torch");
  btn.hidden = !(caps && caps.torch);
  let on = false;
  btn.onclick = async () => { on = !on; try{ await track.applyConstraints({advanced:[{torch:on}]}); }catch(e){} btn.textContent = on ? "Light off" : "Flashlight"; };
}
function closeCam(){
  stopLoop?.(); stopLoop = null;
  try{ zxReader?.reset(); }catch(e){} zxReader = null;
  stream?.getTracks?.().forEach(t => t.stop()); stream = null;
  $("#video").srcObject = null;
  $("#cam").hidden = true;
}
function onCode(code){
  if(handled) return; handled = true;
  try{ navigator.vibrate?.(60); }catch(e){}
  closeCam();
  lookup(code);
}
$("#openCam").onclick = openCam;
$("#closeCam").onclick = closeCam;
document.addEventListener("visibilitychange", () => { if(document.hidden && !$("#cam").hidden) closeCam(); });

/* ---------- Forms ---------- */
$("#codeForm").addEventListener("submit", e => { e.preventDefault(); lookup($("#code").value); $("#code").blur(); });
$("#foodForm").addEventListener("submit", e => { e.preventDefault(); checkFood($("#food").value); $("#food").blur(); });

/* ---------- Start ---------- */
calcWeek(); renderGuide(); renderHistory();
if(!store.get("hist", []).length){
  $("#result").innerHTML = `<div class="card"><span class="label">How it works</span><p>Scan any food or drink. She'll get <b style="color:var(--ok)">Yes</b>, <b style="color:var(--limit)">Careful</b> or <b style="color:var(--avoid)">No</b>, with the reason. Try typing <b>brie</b> below to see an example.</p></div>`;
}
if("serviceWorker" in navigator) addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
