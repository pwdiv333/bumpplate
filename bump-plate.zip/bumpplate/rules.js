/* Bump Plate — pregnancy food rules (US guidance: FDA, CDC, USDA, ACOG).
   General guidance for a typical pregnancy. Her OB or midwife's advice comes first. */

const FOODS = [
 {cat:"Meat & deli", items:[
  {n:"Deli meat, cold cuts, lunch meat", k:["deli","cold cut","lunch meat","turkey slices","salami","bologna","pastrami","roast beef slices","turkey sandwich","ham sandwich","sliced ham","sub sandwich","hoagie","prosciutto","pepperoni"], s:"limit", d:"Only if heated until steaming hot (165°F), like a toasted panini. Cold deli meat can carry listeria."},
  {n:"Hot dogs", k:["hot dog","frank","wiener","bratwurst"], s:"limit", d:"Fine when cooked until steaming. Not cold from the pack. Wash hands after handling."},
  {n:"Dry-cured meats (salami, prosciutto, chorizo)", k:["salami","prosciutto","chorizo","soppressata","charcuterie"], s:"limit", d:"Avoid uncooked. Fine cooked into a dish, like pepperoni baked on pizza."},
  {n:"Refrigerated pâté and meat spreads", k:["pate","pâté","meat spread","liverwurst"], s:"avoid", d:"Listeria risk. Canned or shelf-stable versions are okay."},
  {n:"Rare or pink meat", k:["rare","medium rare","steak tartare","tartare","carpaccio","pink burger"], s:"avoid", d:"Cook steaks and roasts to 145°F with a 3-minute rest, ground meat to 160°F, poultry to 165°F."},
  {n:"Well-cooked beef, pork, chicken", k:["chicken","beef","pork","steak","burger","turkey","meatball","jerky"], s:"ok", d:"Great protein and iron. Use a thermometer: 145°F whole cuts, 160°F ground, 165°F poultry."},
  {n:"Liver", k:["liver","foie gras"], s:"limit", d:"Very high in vitamin A, which is harmful in large amounts. Skip or keep to a rare small portion."},
  {n:"Store deli salads (chicken, ham, tuna, seafood salad)", k:["chicken salad","ham salad","tuna salad","seafood salad","egg salad"], s:"limit", d:"Avoid ones from the deli counter. Homemade with fresh, well-chilled ingredients is fine."}
 ]},
 {cat:"Fish & seafood", items:[
  {n:"Low-mercury fish (salmon, shrimp, cod, tilapia, sardines, canned light tuna)", k:["salmon","shrimp","cod","tilapia","sardine","pollock","catfish","light tuna","canned tuna","trout","scallop","crab","lobster","anchovy","fish"], s:"ok", d:"Encouraged: 2–3 servings (8–12 oz) a week, fully cooked. Good source of omega-3s for baby's brain."},
  {n:"Albacore (white) tuna, tuna steak", k:["albacore","white tuna","tuna steak","yellowfin","halibut","mahi"], s:"limit", d:"FDA 'good choice': up to 1 serving a week, in place of best-choice fish."},
  {n:"High-mercury fish", k:["swordfish","shark","king mackerel","marlin","orange roughy","tilefish","bigeye"], s:"avoid", d:"Skip entirely: shark, swordfish, king mackerel, marlin, orange roughy, bigeye tuna, Gulf of Mexico tilefish."},
  {n:"Raw fish (sushi, sashimi, poke, ceviche)", k:["sushi","sashimi","poke","ceviche","raw fish","crudo"], s:"avoid", d:"Raw fish can carry parasites and bacteria. Cooked rolls (shrimp tempura, eel, California roll with cooked crab) are fine."},
  {n:"Raw oysters, clams, mussels", k:["oyster","clam","mussel","raw bar"], s:"avoid", d:"Cooked until shells open is fine."},
  {n:"Refrigerated smoked fish (lox, nova)", k:["lox","smoked salmon","nova","gravlax","kippered"], s:"limit", d:"Only if cooked into a dish. Canned or shelf-stable smoked fish is fine."}
 ]},
 {cat:"Dairy & eggs", items:[
  {n:"Raw (unpasteurized) milk and cheese", k:["raw milk","unpasteurized","raw milk cheese"], s:"avoid", d:"Check the label for 'pasteurized'. Farmers market cheese is the usual surprise."},
  {n:"Soft cheeses (brie, camembert, feta, blue, goat)", k:["brie","camembert","feta","blue cheese","gorgonzola","goat cheese","chevre","roquefort","soft cheese"], s:"limit", d:"Okay only if the label says pasteurized milk. Heated until bubbling is safest."},
  {n:"Queso fresco, panela, queso blanco", k:["queso fresco","panela","queso blanco","cotija"], s:"limit", d:"Linked to listeria outbreaks even when pasteurized. Eat only if cooked hot."},
  {n:"Hard cheeses (cheddar, parmesan, swiss)", k:["cheddar","parmesan","swiss","gouda","mozzarella","string cheese","cheese","provolone"], s:"ok", d:"Pasteurized hard and processed cheeses are safe."},
  {n:"Yogurt, milk, cottage cheese, cream cheese", k:["yogurt","milk","cottage cheese","cream cheese","kefir","sour cream","butter"], s:"ok", d:"Pasteurized dairy is a great calcium source."},
  {n:"Ice cream", k:["ice cream","gelato","frozen yogurt"], s:"ok", d:"Store-bought is fine. Soft-serve machines have had listeria problems, so go easy there."},
  {n:"Raw or runny eggs", k:["runny egg","raw egg","over easy","sunny side","soft boiled","poached egg","hollandaise","eggs benedict","aioli","homemade mayo","caesar dressing","tiramisu","mousse","eggnog"], s:"avoid", d:"Cook until yolk and white are firm. Pasteurized eggs are the exception. Store-bought mayo is fine."},
  {n:"Fully cooked eggs", k:["egg","scrambled","hard boiled","omelet","quiche","frittata"], s:"ok", d:"Excellent source of choline and protein."}
 ]},
 {cat:"Produce & grains", items:[
  {n:"Raw sprouts (alfalfa, clover, mung bean, radish)", k:["sprout","alfalfa","bean sprout"], s:"avoid", d:"Bacteria get inside the seeds and can't be washed off. Cook thoroughly or skip."},
  {n:"Fruits and vegetables", k:["fruit","vegetable","salad","apple","banana","berries","spinach","broccoli","avocado","lettuce","melon","cantaloupe","watermelon"], s:"ok", d:"Rinse well under running water. Eat cut melon right away or keep it cold."},
  {n:"Raw cookie dough and batter", k:["cookie dough","raw dough","batter","raw flour"], s:"avoid", d:"Raw flour and raw eggs both carry risk. Baked is fine."},
  {n:"Unpasteurized juice or cider", k:["unpasteurized juice","fresh pressed","cold pressed","farm cider","juice bar"], s:"avoid", d:"Look for 'pasteurized' or treated on the label. Juice bars are usually unpasteurized. HPP-treated is okay."}
 ]},
 {cat:"Drinks", items:[
  {n:"Alcohol (all kinds)", k:["alcohol","wine","beer","cocktail","liquor","vodka","hard seltzer","margarita","mimosa","sake"], s:"avoid", d:"No amount is known to be safe at any point in pregnancy. Alcohol-free beer and wine are better swaps."},
  {n:"Coffee and caffeine", k:["coffee","latte","espresso","cold brew","tea","soda","cola","matcha","caffeine","chai","cappuccino"], s:"limit", d:"Keep under 200 mg a day (ACOG): about one 12-oz coffee. Tea, soda and chocolate count too."},
  {n:"Energy drinks", k:["energy drink","red bull","monster","bang","celsius","pre-workout","preworkout"], s:"avoid", d:"High caffeine plus stimulants like guarana and ginseng that haven't been studied in pregnancy."},
  {n:"Kombucha", k:["kombucha"], s:"limit", d:"Often unpasteurized with traces of alcohol. Many OBs say skip it."},
  {n:"Herbal teas", k:["herbal tea","raspberry leaf","chamomile","peppermint tea","ginger tea","hibiscus"], s:"limit", d:"Ginger and peppermint are commonly okay. Ask her provider about others, especially raspberry leaf near term."},
  {n:"Water, sparkling water, milk", k:["water","sparkling","electrolyte"], s:"ok", d:"Aim for roughly 8–12 cups of fluid a day."}
 ]},
 {cat:"Leftovers & eating out", items:[
  {n:"Leftovers", k:["leftover"], s:"ok", d:"Refrigerate within 2 hours, eat within 3–4 days, reheat to 165°F (steaming)."},
  {n:"Buffets and salad bars", k:["buffet","salad bar","potluck"], s:"limit", d:"Food that sits at room temp is risky. Choose hot items that are steaming."}
 ]}
];

const TRI = {
 1:{name:"First trimester", focus:[["Folic acid","600 mcg / day"],["Extra calories","None yet"],["Caffeine","Under 200 mg"]],
  tips:["Prenatal vitamin with folic acid every day. It helps prevent neural tube defects, which form in the first weeks.","For nausea: small meals every 2–3 hours, crackers before getting up, cold foods, ginger tea or ginger chews.","If she can only keep down bland food, that's okay for now. Hydration matters most.","All listeria, mercury and raw-food rules already apply."]},
 2:{name:"Second trimester", focus:[["Iron","27 mg / day"],["Calcium","1,000 mg / day"],["Extra calories","About 340 / day"]],
  tips:["Iron needs climb. Pair red meat, beans or spinach with vitamin C (citrus, peppers) to absorb more.","Calcium builds baby's bones: dairy, fortified plant milk, canned salmon with bones.","Gestational diabetes screening usually happens around weeks 24–28. Her provider may adjust her diet after.","Two to three servings of low-mercury fish a week for omega-3s."]},
 3:{name:"Third trimester", focus:[["Extra calories","About 450 / day"],["Omega-3 (DHA)","200+ mg / day"],["Fluids","8–12 cups"]],
  tips:["Heartburn is common: smaller meals, less spicy and fatty food, stay upright after eating.","Fiber and water help with constipation: oats, prunes, berries, beans.","Baby's brain grows fast now. Salmon, sardines and eggs are great.","Food rules don't relax. Listeria in late pregnancy is still dangerous."]}
};

/* ---------- Typed-food matching ---------- */
const RANK = {avoid:3, limit:2, ok:1};
function wordRe(k){ return new RegExp("(^|[^a-zà-ÿ])" + k.replace(/[.*+?^${}()|[\]\\]/g,"\\$&") + "(s|es)?([^a-zà-ÿ]|$)", "i"); }
function matchFood(q){
  const all = FOODS.flatMap(c => c.items);
  const hits = all.filter(i => i.k.some(k => wordRe(k).test(q)));
  if(!hits.length) return [];
  const top = Math.max(...hits.map(h => RANK[h.s]));
  return hits.filter(h => RANK[h.s] === top || (top < 3 && RANK[h.s] >= 2));
}

/* ---------- Scanned-product rules ----------
   Each rule looks at the product's name, categories, labels and ingredients from Open Food Facts.
   level: no | careful. If nothing fires, the product gets "yes". */
const PRODUCT_RULES = [
 // Alcohol
 {level:"no", why:"Contains alcohol. No amount is known to be safe in pregnancy.",
  test:p => p.alcohol > 0.5 || has(p.cats,["alcoholic-beverages","wines","beers","spirits","liqueurs","ciders","hard-seltzers","cocktails"]) && !has(p.cats,["non-alcoholic","alcohol-free"]) },
 {level:"careful", why:"Labeled alcohol-free or non-alcoholic. These can still contain up to 0.5% alcohol. Many OBs are fine with them; check with hers.",
  test:p => has(p.cats,["non-alcoholic","alcohol-free"]) || /non[- ]?alcoholic|alcohol[- ]free|0\.0%/.test(p.name) && /beer|wine|bier|ale|lager/.test(p.name) },
 {level:"careful", why:"Made with wine, beer or spirits. Usually fine if the product was cooked or baked; avoid if it's a drink or uncooked dessert.",
  test:p => !p.isAlcoholic && /\b(wine|beer|rum|brandy|bourbon|whiskey|whisky|vodka|liqueur|sherry|marsala|sake|ethanol|ethyl alcohol)\b/.test(p.ing) && !/vinegar/.test(p.ingNear(/wine|sherry|rice wine/)) },
 // Stimulants
 {level:"no", why:"Energy drink. High caffeine plus stimulants that haven't been studied in pregnancy.",
  test:p => has(p.cats,["energy-drinks"]) || /energy drink/.test(p.name) || (/guarana|taurine/.test(p.ing) && /caffeine/.test(p.ing)) },
 {level:"no", why:"Contains herbal ingredients that aren't recommended in pregnancy.", flag:"herb",
  test:p => /\b(ginseng|yohimb|kava|black cohosh|blue cohosh|dong quai|st\.? john'?s wort|pennyroyal|mugwort|ephedra|ma huang|garcinia|bitter orange|synephrine|senna|ashwagandha)\b/.test(p.ing) },
 {level:"careful", why:"Contains caffeine. Keep her total under 200 mg a day (ACOG).", caffeine:true,
  test:p => p.caffeine > 0 || /\b(caffeine|coffee|espresso|guarana|yerba mate|mate|matcha|green tea|black tea|tea extract|cola nut|kola)\b/.test(p.ing) || has(p.cats,["coffees","teas","colas","energy-drinks"]) && !/decaf|caffeine[- ]free|herbal/.test(p.name) },
 {level:"careful", why:"Herbal tea. Ginger and peppermint are commonly okay; ask her provider about others, especially raspberry leaf near term.",
  test:p => has(p.cats,["herbal-teas","infusions","herbal-tea"]) || /herbal tea|tisane|raspberry leaf/.test(p.name) },
 {level:"careful", why:"Kombucha is often unpasteurized and has traces of alcohol. Many OBs say skip it.",
  test:p => /kombucha/.test(p.name + " " + p.catText) },
 // Raw / unpasteurized
 {level:"no", why:"Made with raw (unpasteurized) milk. Listeria risk.",
  test:p => has(p.labels,["raw-milk"]) || /\b(raw milk|unpasteuri[sz]ed milk|lait cru)\b/.test(p.ing + " " + p.name) },
 {level:"no", why:"Unpasteurized juice or cider. Can carry E. coli and salmonella.",
  test:p => /unpasteuri[sz]ed/.test(p.all) && /juice|cider|kombucha/.test(p.all) },
 {level:"careful", why:"Cold-pressed juice. Fine only if the label says pasteurized or HPP (high pressure processed).",
  test:p => /cold[- ]pressed/.test(p.name) && !/pasteuri[sz]ed|hpp|high pressure/.test(p.all) },
 // Listeria-risk ready-to-eat
 {level:"careful", why:"Deli meat or cold cuts. Only eat heated until steaming hot (165°F).",
  test:p => has(p.cats,["sliced-meats","cold-cuts","deli-meats","hams","salamis","bolognas","lunch-meats","prepared-meats","dry-sausages","chorizos","pepperoni","prosciutto","cured-meats","charcuterie"]) || /\b(deli|lunch meat|cold cuts?|salami|bologna|pastrami|prosciutto|pepperoni|soppressata|sliced (ham|turkey|chicken))\b/.test(p.name) },
 {level:"careful", why:"Hot dogs and sausages. Cook until steaming hot; don't eat cold from the pack.",
  test:p => has(p.cats,["hot-dogs","frankfurters","sausages"]) || /\b(hot dogs?|franks?|wieners?|frankfurters?|bratwurst)\b/.test(p.name) },
 {level:"no", why:"Refrigerated pâté or meat spread. Listeria risk. Canned, shelf-stable versions are okay.",
  test:p => (has(p.cats,["pates","liver-pates","meat-spreads"]) || /\b(p[aâ]t[eé]|liverwurst|rillettes)\b/.test(p.name)) && !has(p.cats,["canned-foods","canned-meats"]) },
 {level:"careful", why:"Refrigerated smoked fish (lox, nova). Only if cooked into a dish. Canned smoked fish is fine.",
  test:p => (has(p.cats,["smoked-salmons","smoked-fishes","smoked-trout"]) || /\b(smoked salmon|lox|nova|gravlax|kippered)\b/.test(p.name)) && !has(p.cats,["canned-foods","canned-fishes"]) },
 {level:"careful", why:"Soft or fresh cheese. Okay only if made with pasteurized milk; heated until bubbling is safest.",
  test:p => has(p.cats,["soft-cheeses","bries","camemberts","blue-cheeses","fetas","goat-cheeses","bloomy-rind-cheeses","washed-rind-cheeses"]) || /\b(brie|camembert|feta|gorgonzola|roquefort|stilton|blue cheese|chevre|goat cheese|limburger)\b/.test(p.name) },
 {level:"careful", why:"Queso fresco-style cheese has been linked to listeria outbreaks even when pasteurized. Eat only cooked hot.",
  test:p => /\b(queso fresco|queso blanco|panela|cotija|requeson)\b/.test(p.name + " " + p.catText) },
 {level:"careful", why:"Store-made salad (chicken, tuna, ham, egg, seafood). Listeria risk from refrigerated ready-to-eat salads.",
  test:p => /\b(chicken|tuna|ham|egg|seafood|crab|shrimp|lobster) salad\b/.test(p.name) },
 {level:"no", why:"Contains raw sprouts. Bacteria live inside the seed and can't be washed off.",
  test:p => /\b(alfalfa|clover|mung bean|radish|broccoli) sprouts?\b|\bbean sprouts?\b/.test(p.name + " " + p.ing) },
 {level:"careful", why:"Raw cookie dough or batter. Bake it first; raw flour and eggs carry risk. Labeled 'safe to eat raw' or heat-treated is okay.",
  test:p => /cookie dough|brownie batter|cake batter|pizza dough|biscuit dough/.test(p.name) && !/safe to eat raw|heat[- ]treated|edible/.test(p.all) },
 // Fish
 {level:"no", why:"High-mercury fish. Skip entirely in pregnancy.",
  test:p => /\b(swordfish|shark|king mackerel|marlin|orange roughy|tilefish|bigeye)\b/.test(p.name + " " + p.ing) },
 {level:"careful", why:"Albacore (white) tuna. Limit to 1 serving a week. Canned light tuna is the better pick.",
  test:p => /albacore|white tuna|solid white|yellowfin|ahi/.test(p.name + " " + p.ing) },
 {level:"no", why:"Raw fish (sushi, sashimi, poke). Choose cooked rolls instead.",
  test:p => /\b(sashimi|poke|ceviche|raw fish|nigiri)\b/.test(p.name) },
 // Vitamin A, liver
 {level:"careful", why:"Liver products are very high in vitamin A, which is harmful in large amounts. Skip or keep to a rare small portion.",
  test:p => /\bliver\b/.test(p.name) || /\b(cod liver oil|beef liver|chicken liver|pork liver)\b/.test(p.ing) },
 {level:"careful", why:"Supplement. Check with her provider before adding anything beyond her prenatal vitamin, especially vitamin A (retinol).",
  test:p => has(p.cats,["dietary-supplements","food-supplements","vitamins"]) },
];

function has(list, keys){ return keys.some(k => list.some(t => t.endsWith(":"+k) || t === k)); }

/* Normalize an Open Food Facts product into the fields the rules read. */
function normalizeProduct(raw){
  const lc = s => String(s||"").toLowerCase();
  const name = lc([raw.product_name, raw.product_name_en, raw.generic_name, raw.brands].filter(Boolean).join(" "));
  const ing = lc(raw.ingredients_text_en || raw.ingredients_text || "");
  const cats = raw.categories_tags || [];
  const labels = raw.labels_tags || [];
  const n = raw.nutriments || {};
  const p = {
    name, ing, cats, labels,
    catText: lc(cats.join(" ").replace(/[a-z]{2}:/g,"").replace(/-/g," ")),
    alcohol: Number(n.alcohol_100g ?? n.alcohol ?? 0) || 0,
    caffeine: Number(n.caffeine_100g ?? 0) || 0,
    caffeineServing: Number(n.caffeine_serving ?? 0) || 0,
    servingSize: raw.serving_size || "",
    hasIngredients: !!ing,
  };
  p.all = name + " " + ing + " " + p.catText + " " + labels.join(" ");
  p.isAlcoholic = p.alcohol > 0.5 || has(cats,["alcoholic-beverages","wines","beers","spirits","liqueurs"]);
  p.ingNear = re => { const m = ing.match(new RegExp("[^,;()]*(" + re.source + ")[^,;()]*")); return m ? m[0] : ""; };
  return p;
}

/* Returns {verdict: "yes"|"careful"|"no", reasons:[...], caffeineNote} */
function checkProduct(raw){
  const p = normalizeProduct(raw);
  const fired = PRODUCT_RULES.filter(r => { try { return r.test(p); } catch(e){ return false; } });
  // Dedupe overlapping alcohol rules: a hard "no" for alcohol makes the "made with wine" note redundant
  let reasons = fired;
  if(fired.some(r => r.why.startsWith("Contains alcohol"))) reasons = fired.filter(r => !r.why.startsWith("Made with wine") && !r.why.startsWith("Labeled alcohol-free"));
  if(fired.some(r => r.why.startsWith("Energy drink"))) reasons = reasons.filter(r => !r.caffeine);
  let verdict = reasons.some(r => r.level === "no") ? "no" : reasons.length ? "careful" : "yes";
  if(verdict === "yes" && !p.hasIngredients && !p.cats.length) verdict = "careful";
  let caffeineNote = "";
  if(reasons.some(r => r.caffeine) || verdict === "no" && p.caffeine){
    const mgServing = p.caffeineServing ? p.caffeineServing * (p.caffeineServing < 1 ? 1000 : 1) : 0;
    const mg100 = p.caffeine ? p.caffeine * (p.caffeine < 1 ? 1000 : 1) : 0;
    if(mgServing) caffeineNote = `About ${Math.round(mgServing)} mg caffeine per serving${p.servingSize ? " ("+p.servingSize+")" : ""}.`;
    else if(mg100) caffeineNote = `About ${Math.round(mg100)} mg caffeine per 100 g/ml.`;
  }
  const out = reasons.map(r => r.why);
  if(verdict === "yes"){
    out.push(p.hasIngredients
      ? "No pregnancy red flags in the ingredients, categories or labels."
      : "No red flags in the product info, but the ingredient list isn't in the database. Give the label a quick look.");
  }
  return {verdict, reasons: out, caffeineNote, missingIngredients: !p.hasIngredients};
}

if(typeof module !== "undefined") module.exports = {FOODS, TRI, matchFood, checkProduct};
