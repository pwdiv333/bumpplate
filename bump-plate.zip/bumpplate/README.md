# Bump Plate

A pregnancy food guide and barcode scanner for Alexa. Scan any packaged food or drink to get **Yes / Careful / No** with the reason, check a food or dish by name, browse the full eat/avoid guide, and see what matters at her current week.

- Live camera barcode scanning (works on iPhone Safari and Android Chrome)
- Product data from Open Food Facts (free, no account or API key)
- Installs to the home screen and opens offline (scanning needs a connection)
- Nothing leaves her phone except the barcode number sent to Open Food Facts

## Put it online (free, about 5 minutes)

The camera only works over HTTPS, so the folder needs a real web host. Either option below is free.

### Option A: Netlify Drop (easiest, needs a computer)
1. Unzip `bump-plate.zip` on a computer.
2. Go to https://app.netlify.com/drop and drag the `bumpplate` folder onto the page.
3. Sign up (free) when asked so the site stays up. You get a link like `https://something.netlify.app`.
4. Optional: in Site settings, rename it to something like `bumpplate-alexa`.

### Option B: GitHub Pages
1. Create a new public repository on GitHub and upload every file in this folder.
2. Settings → Pages → Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. The site appears at `https://<username>.github.io/<repo>/` within a minute or two.

## Install it on her phone
- **iPhone:** open the link in Safari → Share → **Add to Home Screen**.
- **Android:** open in Chrome → menu (⋮) → **Install app** / **Add to Home screen**.

The first scan asks for camera permission. Tap Allow.

## Files
| File | What it does |
|---|---|
| `index.html` | Layout and styles |
| `app.js` | Scanner, lookups, tabs, due-date math, scan history |
| `rules.js` | The food guide and the product safety rules. Edit here to change any verdict. |
| `zxing.min.js` | Barcode reader for phones without a built-in one (iPhone). Loaded only when needed. |
| `sw.js`, `manifest.webmanifest`, icons | Home-screen install and offline support |

## How verdicts work
`rules.js` checks each product's name, categories, labels and ingredients for pregnancy red flags: alcohol, energy drinks and caffeine, unpasteurized milk or juice, deli meats and hot dogs, refrigerated pâté and smoked fish, soft and Hispanic-style fresh cheeses, raw sprouts, raw dough, high-mercury fish, raw fish, liver, herbal stimulants and supplements. If none fire, it's a **Yes**. Open Food Facts is volunteer-built, so a product can be missing or have an incomplete ingredient list; the app says so when that happens.

Sources: FDA "Food Safety for Moms-to-Be", FDA/EPA Advice About Eating Fish, USDA safe minimum cooking temperatures, ACOG guidance on caffeine (under 200 mg/day) and nutrition in pregnancy.

This is a general guide, not medical advice. Her OB or midwife's advice comes first.
